//equação que retorna o maior entre dois números.
// (A+B + |A-B|)/2

var A;
var B;

//A = parseInt(prompt('digite o primeiro número.'));
//B = parseInt(prompt('digite o segundo número.'));

A=30
B=1024
var C = ((A+B)+Math.abs(A-B))/2;

console.log('O maior número é: '+C);


