var numero = 3.5;
//arredonda o número para o valor inteiro abaixo.
//console.log(Math.floor(numero));
//arredonda o número para o inteiro mais próximo.
//console.log(Math.round(numero));
//arredonda o número para o valor acima 
//console.log(Math.ceil(numero));
//Pega a parte inteira de um número.
//console.log(Math.trunc(numero));
//expoente
//var base = 9;
//elevar um número a uma determinada potência.
//console.log(base**2);
//console.log(Math.pow(base,2));
//tirar raiz quadrada.
//console.log(Math.sqrt(base));
//raiz cúbica.
//base*=3;
//console.log(Math.cbrt(base));

//Retorna o maior entre N termos.
//Math.max(A,B,100,2048));
//min retorna o menor
//console.log(Math.round(Math.random()*12)-10);




