contador = 1;
somador = 0;

//quero somar todos os números de 1 até 100.

while(contador<=100){
    console.log(contador);
    somador+=contador;
    contador++;
}

console.log(somador);