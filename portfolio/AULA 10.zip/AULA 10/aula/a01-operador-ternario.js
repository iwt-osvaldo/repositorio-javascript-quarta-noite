altura = -4.75;

permitido = altura >=0 && altura>=1.22 && altura <=3;

var resposta = permitido ? "pode descer no insano" : "não pode descer no insano";

console.log(resposta);

