var opcao = 'a';

switch(opcao){

    case 'a': console.log('novo arquivo.');
            break;

    case 'b': console.log('nova janela.');
            break;
    case 'c': console.log('abrir arquivo.');
            break;
    case 'd': console.log('abrir pasta.');
            break;
    case 'e': console.log('salvar.');
            break;
    default: console.log('opção inválida.')
}
